
import React from 'react';
// eslint-disable-next-line import/no-anonymous-default-export
export default props => {
    return (
        <div>
            <h1 className='col text-white text-center bg-primary mt-5'>Recode Pro {props.ano}! </h1>
            <br /><br /><br />
            <h3 className='col text-white text-center bg-success p-5 '>A Sabrina A-G-R-A-D-E-C-E imensamente a oportunidade incrível de aprendizado!!!!!!!!!!!*_* :)</h3>
            <br /><br /><br />
            <h3 className='text-white col text-center bg-secondary p-5'>*_* :)!!!!!! *** MUITO OBRIGADA *** !!!!!!*_* :)</h3>
        </div>
    )
};




