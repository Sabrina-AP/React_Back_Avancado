import styles from './Estilos.module.css';
export default function Pagina2() {
  return (
    <div className={styles.text2}>

      <h3> Aqui em nossa loja, <i>programadores tem desconto</i> nos produtos para sua casa!</h3>

    </div>
  );
}